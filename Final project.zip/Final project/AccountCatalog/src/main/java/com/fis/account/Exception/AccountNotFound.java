package com.fis.account.Exception;

public class AccountNotFound extends RuntimeException{


	public AccountNotFound(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
	
}
