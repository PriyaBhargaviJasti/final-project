package com.fis.custservice;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.persistence.PersistenceException;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.validation.annotation.Validated;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.fis.custservice.model.Customer;
import com.fis.custservice.service.CustomerService;
import com.fis.custservice.dao.CustomerDao;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
//import com.fis.custservice.model.Account;
//import com.fis.custservice.service.AccountService;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

//import com.fis.bankapp.model.Transaction;
//import com.fis.bankapp.exception.AccountNotFound;
import com.fis.custservice.exception.CustomerNotFound;
import com.fis.custservice.exception.NoRecordsException;
//import com.fis.bankapp.service.TransactionService;

@SpringBootTest
class BankAppApplication {
	
	@MockBean
	CustomerDao dao;
	
	@Autowired
	CustomerService service;

	private MockMvc mockMvc;

//	@Test
//	public void testAddCustomer() {
//		Customer customer = new Customer(1,"priya",new Date(), 456785677l, "priya@gmail.com", "fcgvhb");
//		
//		String msg = service.addCustomer(customer);
//		assertEquals("Customer added successfully",msg);
//	}
	
	@Test
	public void testAddCustomer() {
		Customer customer = new Customer(1,"priya",new Date(), 456785677l, "priya@gmail.com", "fcgvhb");
		Mockito.when(dao.save(customer)).thenReturn(customer);
		boolean res = service.addCustomer(customer);
		System.out.println(res);
		assertTrue(res);
	}
	
	@Test
	public void testUpdateCustomer() {
		Customer customer = new Customer(1,"priya",new Date(), 456785677l, "priya@gmail.com", "fcgvhb");
		Mockito.when(dao.save(customer)).thenReturn(customer);
		boolean res = service.updateCustomer(customer);
		System.out.println(res);
		assertTrue(res);
	}
	
	@Test
	@DisplayName("Delete Account")
	public void testDeleteCustomer() throws NoRecordsException{
		Customer customer = new Customer(1,"priya",new Date(), 456785677l, "priya@gmail.com", "fcgvhb");
		Mockito.when(dao.save(customer)).thenReturn(customer);
		
		//Mockito.verify(dao, times(1)).deleteAll();
		try {
			Optional<Customer> custList=Optional.of(customer);
			//
			Mockito.when(dao.findById(customer.getCustId())).thenReturn(custList);
		Mockito.when(dao.deleteCustomer(customer.getCustId())).thenReturn(1);		
		boolean res = service.deleteCustomer(customer.getCustId());
		assertTrue(res);
		}
		catch (NoRecordsException e){
        	e.getMessage();
        	
        }
	}
	
	
	
	@Test
	@DisplayName("View Customer By Id- Successful")
	public void getAll() throws NoRecordsException{
 
		Customer customer = new Customer(1,"priya",new Date(), 456785677l, "priya@gmail.com", "fcgvhb");
		Mockito.when(dao.save(customer)).thenReturn(customer);
		List<Customer> custList=new ArrayList<Customer>();
		List<Customer> recustList= new ArrayList<Customer>();
        try {
        Mockito.when(dao.findAll()).thenReturn(custList);
       	recustList = service.getAll();
       	assertEquals(custList, recustList);
        }
        catch (NoRecordsException e){
        	e.getMessage();
        	
        }
       
	}
	
	
	
	
//	@Test
//	public void testUpdateCustomer() throws CustomerNotFound {
//		Customer customer = new Customer(1,"priya",new Date(), 456786798l, "priya@gmail.com", "fcgvhb");
//	
//		String msg = service.updateCustomer(customer);
//		assertEquals("Customer updated successfully",msg);
//	}
//	
//	@Test
//	public void testDeleteCustomer() throws CustomerNotFound {
//		Customer customer = new Customer(1,"priya",new Date(), 456787799l, "priya@gmail.com", "fcgvhb");
//		
//		service.addCustomer(customer);
//		String msg = service.deleteCustomer(1);
//		assertEquals("Customer deleted successfully",msg);
//	}
//	
//	
//	
//	
//	@Test
//	public void testAddAccount() {
//		Account account = new Account(1,"savings","xcvh", "ghjn", 567);
//
//		String msg = service2.addAccount(account);
//		assertEquals("Account created successfully",msg);
//	}
//	
//	
//	@Test
//	public void testUpdateAccount() {
//		Account account = new Account(1,"savings","xcvh", "ghjn", 567);
//		String msg = service2.updateAccount(account);
//		assertEquals("Account updated successfully",msg);
//	}
//	
//	
//	@Test
//	public void testDeleteAccount() throws AccountNotFound {
//		Account account = new Account(1,"savings","xcvh", "ghjn", 567);
//		
//		service2.addAccount(account);
//		String msg = service2.deleteAccount(1);
//		assertEquals("Account deleted successfully",msg);
//	}
//	
//	
//	
//	@Test
//	public void testAddTransaction() {
//		Transaction transaction = new Transaction(12367,5678,4567,LocalDateTime.now(), "withdraw");
//		
//		String msg = service3.addTransaction(transaction);
//		assertEquals("Transaction added",msg);
//	}

}
