package com.fis.transservice.model;

import java.util.List;

public class TransactionDTO {

	private List<Transaction> list;

	public List<Transaction> getList() {
		return list;
	}

	public void setList(List<Transaction> list) {
		this.list = list;
	}

	public TransactionDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
}
