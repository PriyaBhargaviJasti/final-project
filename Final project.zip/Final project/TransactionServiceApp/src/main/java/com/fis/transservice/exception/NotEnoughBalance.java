package com.fis.transservice.exception;

public class NotEnoughBalance extends Exception {

	public NotEnoughBalance(String message) {
		super(message);
	}

}
