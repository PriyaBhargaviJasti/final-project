package com.fis.accservice.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fis.accservice.dao.AccountDao;
import com.fis.accservice.exception.AccountNotFound;
import com.fis.accservice.exception.NoRecordsException;
import com.fis.accservice.model.Account;
import com.fis.accservice.exception.NotEnoughBalance;

@Service
@Transactional
public class AccountService {

	@Autowired
	private AccountDao dao;
	
	
	public boolean addAccount(Account acc) {
		Account accdb  =	dao.save(acc);
		if(accdb!=null)
			return true;
		else
			return false;
		}
	
	public boolean updateAccount(Account acc) {
		Account accdb  =	dao.save(acc);
		if(accdb!=null)
			return true;
		else
			return false;
		}
	
	public List<Account> getAll()
	{
		List<Account> list=dao.findAll();
		if(list.isEmpty()) {
			throw new NoRecordsException("No records found");
		}
		else {
			return list;
		}
	}
	
	
	
	public boolean deleteAccount(long accNo)
	{
		
		Optional<Account> accdb=dao.findById(accNo);
		Account accdb1=accdb.get();
		if(accdb1!=null) {
			dao.deleteById(accNo);
			return true;
			}
		else {
			throw new NoRecordsException("No record to delete");
		}
	}
	public boolean deleteAll() {
		dao.deleteAll();
		return true;
	}
	
	
	public double depositIntoBalance(long accNo, double depositAmount) throws AccountNotFound {
		
		Optional<Account> optional = dao.findById(accNo);
		if(optional.isPresent()) {
			dao.depositIntoBalance(accNo, depositAmount);
			Optional<Account> optional1 = dao.findById(accNo);
			double updatedbal=optional1.get().getBalance();
			updatedbal= updatedbal+depositAmount;
			return updatedbal;
		} else {
			throw new AccountNotFound("Invalid Account Number");
		}
	
	}
	
	public double withdrawFromBalance(long accNo, double withdrawAmount) throws NotEnoughBalance, AccountNotFound {
		
		Optional<Account> optional = dao.findById(accNo);
		if(optional.isPresent()) {
			Account acc=optional.get();
			double currBalance=acc.getBalance();
			if(currBalance > withdrawAmount) {
				dao.withdrawFromBalance(accNo, withdrawAmount);
				Optional<Account> optional1 = dao.findById(accNo);
				double updatedbal=optional1.get().getBalance();
				updatedbal= updatedbal-withdrawAmount;
				return updatedbal;
			} else {
				throw new NotEnoughBalance("Not Enough Balance");
			}
		} else {
			throw new AccountNotFound("Invalid Account Number");
		}
		
	}
	
	public double fundTransfer(long accNoFrom, long accNoTo, double amount) throws AccountNotFound, NotEnoughBalance{
		
		Optional<Account> optional = dao.findById(accNoTo);
		Optional<Account> optional2 = dao.findById(accNoFrom);
		if(optional.isPresent() & optional2.isPresent()) {
			Account acc=optional2.get();
			double currBalance = acc.getBalance();
			if(currBalance > amount) {
				dao.depositIntoBalance(accNoTo, amount);
				dao.withdrawFromBalance(accNoFrom, amount);
				Optional<Account> optional3 = dao.findById(accNoFrom);
				double updatedbal=optional3.get().getBalance();
				updatedbal= updatedbal-amount;
				return updatedbal;
			} else {
				
				throw new NotEnoughBalance("Not Enough Balance");
			}
			
		} else {
			
			throw new AccountNotFound("Invalid Account Number");
		}
		
	}
}
