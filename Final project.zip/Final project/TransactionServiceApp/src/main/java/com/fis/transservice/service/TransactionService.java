package com.fis.transservice.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fis.transservice.dao.TransactionDao;
import com.fis.transservice.exception.NotEnoughBalance;
import com.fis.transservice.exception.NoRecordsException;
import com.fis.transservice.model.Transaction;

@Service
@Transactional
public class TransactionService {

	@Autowired
	private TransactionDao dao;
	
	public boolean addTransaction(Transaction trans) {
		Transaction transdb  =	dao.save(trans);
		if(transdb!=null)
			return true;
		else
			return false;
		}
	
	
	public List<Transaction> getAll()
	{
		List<Transaction> list=dao.findAll();
		if(list.isEmpty()) {
			throw new NoRecordsException("No records found");
		}
		else {
			return list;
		}
	}
	
	
	
	public boolean deleteTransaction(int transId)
	{
		
		Optional<Transaction> transdb=dao.findById(transId);
		Transaction transdb1=transdb.get();
		if(transdb1!=null) {
			dao.deleteById(transId);
			return true;
			}
		else {
			throw new NoRecordsException("No record to delete");
		}
	}
	public boolean deleteAll() {
		dao.deleteAll();
		return true;
	}
}
