package com.fis.transaction.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fis.transaction.model.Transaction;

public interface TransactionDao extends JpaRepository<Transaction, Integer> {

//	public List<Product> getproducts();
}
