package com.fis.bankapplication.controller;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.omg.IOP.TransactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import com.fis.bankapplication.model.Transaction;
import com.fis.bankapplication.model.Account;
import com.fis.bankapplication.model.AccountDTO;
import com.fis.bankapplication.model.ApplicationUser;
import com.fis.bankapplication.model.Customer;
import com.fis.bankapplication.model.CustomerDTO;
import com.fis.bankapplication.model.TransactionDTO;

@Controller
public class BankController {

	@Autowired
	private RestTemplate restTemplate;
//	@Autowired
//	private DiscoveryClient discoveryClient;
	
	
	
	@GetMapping("/")
	public String home() {
		return "home";
	}
	
	@GetMapping("/createCustomer")
	public String addCustomer() {
		return "addCustomer";
 
	}
	
	@GetMapping("/updateCustomer")
	public String updateCustomer() {
		return "updateCustomer";
 
	}
	
	@GetMapping("/createAccount")
	public String addAccount() {
		return "addAccount";
 
	}
	
	@GetMapping("/updateAccount")
	public String updateAccount() {
		return "updateAccount";
 
	}
	
	@PostMapping("/userlogin")
	public String userLogin(@RequestParam("username") String username,@RequestParam("password") String password , Model model,HttpSession session) {
		System.out.println(username);
		System.out.println(password);
		ApplicationUser user=new ApplicationUser();
		
		user.setUsername(username);
		user.setPassword(password);
		int status;
		try {
			
		ResponseEntity<ApplicationUser> res=restTemplate.postForEntity("http://localhost:8090/authservice/auth", user, ApplicationUser.class);
		ApplicationUser userObj=(ApplicationUser) res.getBody();
		System.out.println(userObj+"authentication success");
		session.setAttribute("userId", userObj.getUserId());
		status=res.getStatusCodeValue();
		System.out.println(res.getStatusCodeValue());
		return "redirect:/customers";
		}
		catch(Exception e)
		{
			status=400;
			model.addAttribute("message","UserName and Password invalid"+e);		
			
			return "home";
		}	
	}
	
	@GetMapping("/customers")
	public String getCustomers(HttpSession session) {
		CustomerDTO dto=restTemplate.getForObject("http://localhost:8083/customerservice/customers",CustomerDTO.class);
		//model.addAttribute("ProductList",dto.getList());
		session.setAttribute("CustomerList", dto.getList());
		return "customerList";
	}
	
	@PostMapping("/addCustomer")
	public String addCustomer(@RequestParam("custId") int custId, 
			@RequestParam("custName") String custName,
			@RequestParam("custDob") @DateTimeFormat(pattern = "yyyy-MM-dd") Date custDob,
			@RequestParam("mobile") long mobile,
			@RequestParam("custMail") String custMail,
			@RequestParam("custAddress") String custAddress,
			Model model,
			HttpSession session) {
			
			Customer cust=new Customer();
			
			cust.setCustId(custId);
			cust.setCustName(custName);
			cust.setCustDob(custDob);
			cust.setMobile(mobile);
			cust.setCustMail(custMail);
			cust.setCustAddress(custAddress);
			int status;
			try {
				
			ResponseEntity<Customer> res=restTemplate.postForEntity("http://localhost:8084/customerservice/addCustomer", cust, Customer.class);
			Customer customer=(Customer) res.getBody();
			System.out.println(customer);
//			session.setAttribute("userId", customer.getUserId());
//			status=res.getStatusCodeValue();
			System.out.println(res.getStatusCodeValue());
			return "redirect:/customers";
			}
			catch(Exception e)
			{
				status=400;
				model.addAttribute("message","UserName and Password invalid"+e);		
				
				return "home";
			}
			
	}
	

	@PostMapping("/updateCustomer")
	public String updateCustomer(@RequestParam("custId") int custId, 
			@RequestParam("custName") String custName,
			@RequestParam("custDob") @DateTimeFormat(pattern = "yyyy-MM-dd") Date custDob,
			@RequestParam("mobile") long mobile,
			@RequestParam("custMail") String custMail,
			@RequestParam("custAddress") String custAddress,		
			Model model,
			HttpSession session) {
			
			Customer cust=new Customer();
			
			cust.setCustId(custId);
			cust.setCustName(custName);
			cust.setCustDob(custDob);
			cust.setMobile(mobile);
			cust.setCustMail(custMail);
			cust.setCustAddress(custAddress);
			int status;
			try {
				
			ResponseEntity<Customer> res=restTemplate.postForEntity("http://localhost:8084/customerService/updateCustomer", cust, Customer.class);
			Customer customer=(Customer) res.getBody();
			System.out.println(customer);
			System.out.println(res.getStatusCodeValue());
			return "redirect:/customers";
			}
			catch(Exception e)
			{
				status=400;
				model.addAttribute("message","UserName and Password invalid"+e);		
				
				return "home";
			}
			
	}
	
	@GetMapping("/deleteCustomer/{custId}")
	public String deleteCustomer(@PathVariable("custId") int custId) {
		restTemplate.delete("http://localhost:8084/customerservice/deleteCustomer/"+custId);
		return "redirect:/customers";
	}
	
	
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	
	
	
	@GetMapping("/accounts")
	public String getAccounts(HttpSession session) {
		AccountDTO dto=restTemplate.getForObject("http://localhost:8073/accountservice/accounts",AccountDTO.class);
		//model.addAttribute("ProductList",dto.getList());
		session.setAttribute("AccountList", dto.getList());
		return "AccountList";
	}
	
	@PostMapping("/addAccount")
	public String addAccount(@RequestParam("accNo") long accNo, 
			@RequestParam("custId") int custId,
			@RequestParam("accType") String accType,
			@RequestParam("branch") String branch,
			@RequestParam("ifsc") String ifsc,
			@RequestParam("balance") double balance,
			Model model,
			HttpSession session) {

			Account acc=new Account();
			
			acc.setAccNo(accNo);
			acc.setCustId(custId);
			acc.setAccType(accType);
			acc.setBranch(branch);
			acc.setIfsc(ifsc);
			acc.setBalance(balance);
			int status;
			try {
				
			ResponseEntity<Account> res=restTemplate.postForEntity("http://localhost:8074/accountservice/addAccount", acc, Account.class);
			Account account=(Account) res.getBody();
			System.out.println(account);
//			session.setAttribute("userId", customer.getUserId());
//			status=res.getStatusCodeValue();
			System.out.println(res.getStatusCodeValue());
			return "redirect:/accounts";
			}
			catch(Exception e)
			{
				status=400;
				model.addAttribute("message","UserName and Password invalid"+e);		
				
				return "home";
			}
			
	}
	
	
	@PostMapping("/updateAccount")
	public String updateAccount(@RequestParam("accNo") long accNo,
			@RequestParam("custId") int custId,
			@RequestParam("accType") String accType,
			@RequestParam("branch") String branch,
			@RequestParam("ifsc") String ifsc,
			@RequestParam("balance") double balance,
			Model model,
			HttpSession session) {
		Account acc=new Account();
		
		acc.setAccNo(accNo);
		acc.setCustId(custId);
		acc.setAccType(accType);
		acc.setBranch(branch);
		acc.setIfsc(ifsc);
		acc.setBalance(balance);
		int status;
		try {
		ResponseEntity<Account> res=restTemplate.postForEntity("http://localhost:8074/accountservice/updateAccount", acc, Account.class);
		Account account=(Account) res.getBody();
		System.out.println(account);
//		session.setAttribute("userId", customer.getUserId());
//		status=res.getStatusCodeValue();
		System.out.println(res.getStatusCodeValue());
		return "redirect:/accounts";
		}
		catch(Exception e)
		{
			status=400;
			model.addAttribute("message","UserName and Password invalid"+e);		
			
			return "home";
		}
	}
	
		
		
	@GetMapping("/deleteAccount/{accNo}")
	public String deleteAccount(@PathVariable("accNo") long accNo) {
		restTemplate.delete("http://localhost:8074/accountservice/deleteAccount/"+accNo);
		return "redirect:/accounts";
	}
	
	
	@GetMapping("/depositIntoBalance")
	public String depositIntoBalance(@RequestParam("accNo") long accNo, @RequestParam("depositAmount") double depositAmount, Model model, HttpSession session) {
		
		double updatedbal = (double) restTemplate.getForObject("http://localhost:8074/accountservice/depositIntoBalance/"+accNo+"/"+depositAmount,Object.class);
		Transaction transaction = new Transaction();
		
		String transType = "Deposit";
		transaction.setAccNoTo(accNo);
		transaction.setAmount(depositAmount);
		transaction.setTransType(transType);
		transaction.setDateOfTrans(LocalDateTime.now());
		transaction.setBalance(updatedbal);
		ResponseEntity<Object> res=restTemplate.postForEntity("http://localhost:8064/transactionservice/addTransaction",transaction,Object.class);
		Transaction transaction1=(Transaction) res.getBody();
		System.out.println(res.getStatusCodeValue());
		return "redirect:/accounts";
	}
	
	
	@GetMapping("/withdrawFromBalance")
	public String withdrawFromBalance(@RequestParam("accNo") long accNo, @RequestParam("withdrawAmount") double withdrawAmount) {
		
		double updatedbal = (double) restTemplate.getForObject("http://localhost:8074/accountservice/withdrawFromBalance/"+accNo+"/"+withdrawAmount,Object.class);
		Transaction transaction = new Transaction();
		
		String transType = "Withdraw";
		transaction.setAccNoFrom(accNo);
		transaction.setAmount(withdrawAmount);
		transaction.setTransType(transType);
		transaction.setDateOfTrans(LocalDateTime.now());
		transaction.setBalance(updatedbal);
		ResponseEntity<Object> res=restTemplate.postForEntity("http://localhost:8064/transactionservice/addTransaction",transaction,Object.class);
		Transaction transaction1=(Transaction) res.getBody();
		System.out.println(res.getStatusCodeValue());
		return "redirect:/accounts";
	}
	

	@GetMapping("/fundTransfer")
	public String fundTransfer(@RequestParam("accNoFrom") long accNoFrom, @RequestParam("accNoTo") long accNoTo, 
			@RequestParam("amount") double amount) {
		double updatedbal = (double) restTemplate.getForObject("http://localhost:8074/accountservice/fundTransfer/"+accNoFrom+"/"+accNoTo+"/"+amount,Object.class);
		Transaction transaction = new Transaction();
		
		String transType = "Fund Transfer";
		transaction.setAccNoFrom(accNoFrom);
		transaction.setAccNoTo(accNoTo);
		transaction.setAmount(amount);
		transaction.setTransType(transType);
		transaction.setDateOfTrans(LocalDateTime.now());
		transaction.setBalance(updatedbal);
		ResponseEntity<Object> res=restTemplate.postForEntity("http://localhost:8064/transactionservice/addTransaction",transaction,Object.class);
		Transaction transaction1=(Transaction) res.getBody();
		System.out.println(res.getStatusCodeValue());
		return "redirect:/accounts";
	}
	
	
	@GetMapping("/transactions")
	public String getTransactions(HttpSession session) {
		TransactionDTO dto=restTemplate.getForObject("http://localhost:8063/transactionservice/transactions",TransactionDTO.class);
		//model.addAttribute("ProductList",dto.getList());
		session.setAttribute("TransactionList", dto.getList());
		return "TransactionList";
	}
	
	@GetMapping("/deleteTransaction/{transId}")
	public String deleteTransaction(@PathVariable("transId") int transId) {
		restTemplate.delete("http://localhost:8064/transactionservice/deleteTransaction/"+transId);
		return "redirect:/accounts"; 
	}
	
	
	
	/*	@GetMapping("/viewCustomer")
	public String getCustomers(HttpSession session) {
		CustomerDTO dto= new CustomerDTO();
		try {
		dto=restTemplate.getForObject("http://localhost:8084/customerservice/getCustomers",CustomerDTO.class);
		
		List<Customer> list=dto.getList();
		System.out.println(list);
		session.setAttribute("customers", list);
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
			return "Customer";
		}
		return "Customer";
	}*/
	
	/*@GetMapping("/placeOrder")
	public String placeOrder(HttpSession session) {
		List<Customer> customerList=(List<Customer>) session.getAttribute("customers");
		List<OrderItem> custs=new ArrayList();
		int grandTotal=0;
		for(Customer c:customerList) {
			OrderItem o=new OrderItem();
			//o.setOrderId(0);
			o.setProductid(c.getProductId());
			o.setProductName(c.getProductname());
			o.setProductPrice(c.getProductPrice());
			o.setQuantity(c.getQuantity());
			o.setSubTotal(c.getSumTotal());
			grandTotal+=c.getSumTotal();
			items.add(o);
		
		}
		session.setAttribute("orderItems",items);
		session.setAttribute("grandTotal",grandTotal);
		
		return "PlaceOrder";
	}*/
	
/*	@PostMapping("/confirmOrder")
	public String confirmOrder(@RequestParam("address") String address,@RequestParam("mode") String mode, HttpSession session) {
		
		long millis=System.currentTimeMillis();  
        java.sql.Date date=new java.sql.Date(millis);  
        if(session.getAttribute("userId")==null) {
        	return "SessionExpired";
        }
		
		Order order=new Order();
		order.setDeliveryAddress(address);
		order.setPaymentMode(mode);
		order.setOrderAmount((int) session.getAttribute("grandTotal"));
		order.setUserid((int) session.getAttribute("userId"));
		order.setOrderItems((List<OrderItem>) session.getAttribute("orderItems"));
		order.setOrderDate(date);
		System.out.println(order.getOrderItems());
		ResponseEntity<Object> res=restTemplate.postForEntity("http://localhost:8085/orderservice/placeOrder", order, Object.class);
		System.out.println(res.getStatusCodeValue());
		restTemplate.delete("http://localhost:8084/cartservice/deleteAll");
		
		
		List<Customer> customerList=null;
		session.setAttribute("customers", customerList);
		
		return "Thanks";
	}*/
	
}







