package com.fis.accservice.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.fis.accservice.model.Account;

public interface AccountDao  extends JpaRepository<Account, Long>{

	@Query("Update Account set balance=balance+ ?2 where accNo=?1")
	@Modifying
	 public  void depositIntoBalance(long accNo, double depositAmount);
 
	@Query("Update Account set balance=balance - ?2 where accNo=?1")
	@Modifying
	public  void withdrawFromBalance(long accNo, double withdrawAmount);
	
	
//	public List<Cart> getAll();
//	public boolean addToCart(Cart item);
//	public boolean delete(int id);
//	public boolean deleteAll();
	
}
