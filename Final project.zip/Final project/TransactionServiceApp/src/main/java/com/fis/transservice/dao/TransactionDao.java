package com.fis.transservice.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fis.transservice.model.Transaction;

public interface TransactionDao  extends JpaRepository<Transaction, Integer>{

//	public List<Cart> getAll();
//	public boolean addToCart(Cart item);
//	public boolean delete(int id);
//	public boolean deleteAll();
	
}
