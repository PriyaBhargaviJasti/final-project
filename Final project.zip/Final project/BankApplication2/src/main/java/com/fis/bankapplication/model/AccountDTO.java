package com.fis.bankapplication.model;

import java.util.List;

public class AccountDTO {

	private List<Account> list;

	public List<Account> getList() {
		return list;
	}

	public void setList(List<Account> list) {
		this.list = list;
	}

	public AccountDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
}
