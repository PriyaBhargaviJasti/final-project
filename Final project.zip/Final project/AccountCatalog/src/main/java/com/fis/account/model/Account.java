package com.fis.account.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;
//import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "accounts")
public class Account {
	@Id
	@GeneratedValue
	@Column(name = "accNo")
	private long accNo;
	private int custId;
	@NotBlank(message = "account type cannot be null or whitespace")
	private String accType;
	@NotBlank(message = "branch cannot be null or whitespace")
	private String branch;
	@NotBlank(message = "ifsc cannot be null or whitespace")
	private String ifsc;
	@Min(value = 0, message = "Balance cannot be less than 0")
	private double balance;
	
	
	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}
	public long getAccNo() {
		return accNo;
	}
	public void setAccNo(long accNo) {
		this.accNo = accNo;
	}
	public String getAccType() {
		return accType;
	}
	public void setAccType(String accType) {
		this.accType = accType;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public String getIfsc() {
		return ifsc;
	}
	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	
	public Account(int custId, long accNo, String accType, String branch, String ifsc, double balance) {
		super();
		this.custId = custId;
		this.accNo = accNo;
		this.accType = accType;
		this.branch = branch;
		this.ifsc = ifsc;
		this.balance = balance;
	}
	
	public Account() {
		// TODO Auto-generated constructor stub
	}
	
}