package com.fis.account.model;

import java.util.List;

public class AccountDTO {

	private List<Account> list;

	public List<Account> getList() {
		return list;
	}

	public void setList(List<Account> list) {
		this.list = list;
	}

	
	
	@Override
	public String toString() {
		return "accountDTO [list=" + list + "]";
	}

	
	
	
}
