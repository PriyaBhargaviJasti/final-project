package com.fis.transservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.fis.transservice.model.Transaction;
import com.fis.transservice.model.TransactionDTO;
import com.fis.transservice.service.TransactionService;

@RestController
public class TransactionController {

	@Autowired
	private TransactionService service;
	
	@GetMapping("/getTransactions")
	public ResponseEntity<TransactionDTO> getTransactions(){
		TransactionDTO dto=new TransactionDTO();
		dto.setList(service.getAll());
		return new ResponseEntity<TransactionDTO>(dto,HttpStatus.OK);
	}
	
	@PostMapping("/addTransaction")
	public ResponseEntity<Object> addTransaction(@RequestBody Transaction trans){
		if(service.addTransaction(trans)) {
			return new ResponseEntity<Object>(HttpStatus.CREATED);
		}
		else
			return new ResponseEntity<Object>(HttpStatus.BAD_REQUEST);
	}
	//cart-customer; item-cust
	
	
	@DeleteMapping("/deleteTransaction/{transId}")
	public ResponseEntity<Object> deleteTransaction(@PathVariable("transId") int transId){
		service.deleteTransaction(transId);
		return new ResponseEntity<Object>("Deleted",HttpStatus.NO_CONTENT);
	}
	
	@DeleteMapping("/deleteAll")
	public ResponseEntity<Object> deleteAll(){
		service.deleteAll();
		return new ResponseEntity<Object>("Deleted",HttpStatus.NO_CONTENT);
	}
}
