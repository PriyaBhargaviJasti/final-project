package com.fis.transservice;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.persistence.PersistenceException;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.validation.annotation.Validated;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.fis.transservice.model.Transaction;
import com.fis.transservice.service.TransactionService;
import com.fis.transservice.dao.TransactionDao;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
//import com.fis.custservice.model.Account;
//import com.fis.custservice.service.AccountService;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

//import com.fis.bankapp.model.Transaction;
//import com.fis.bankapp.exception.AccountNotFound;
//import com.fis.transservice.exception.TransactionNotFound;
import com.fis.transservice.exception.NoRecordsException;
//import com.fis.bankapp.service.TransactionService;

@SpringBootTest
class BankAppApplication {
	
	@MockBean
	TransactionDao dao;
	
	@Autowired
	TransactionService service;

	private MockMvc mockMvc;


	
	@Test
	public void testAddTransaction() {
		Transaction transaction = new Transaction(12367,5678,4567,LocalDateTime.now(), "withdraw");
		Mockito.when(dao.save(transaction)).thenReturn(transaction);
		boolean res = service.addTransaction(transaction);
		System.out.println(res);
		assertTrue(res);
	}
	
	
//	@Test
//	public void testDeleteCustomer() {
//		Customer customer = new Customer(1,"priya",new Date(), 456785677l, "priya@gmail.com", "fcgvhb");
//		Mockito.when(dao.save(customer)).thenReturn(customer);
//		List<Customer> custList=new ArrayList<Customer>();
//
//		Mockito.when(dao.findAll()).thenReturn(custList);
//		Mockito.verify(dao, times(1)).deleteAll();
//		
//		int custId;
//		boolean res = service.deleteAll();
//		System.out.println(res);
//		assertTrue(res);
//	}
	
	
	
	@Test
	@DisplayName("View Transaction By Id- Successful")
	public void getAll() throws NoRecordsException{
 
		Transaction transaction = new Transaction(12367,5678,4567,LocalDateTime.now(), "withdraw");
		Mockito.when(dao.save(transaction)).thenReturn(transaction);
		List<Transaction> transList=new ArrayList<Transaction>();
		List<Transaction> retransList= new ArrayList<Transaction>();
        try {
        Mockito.when(dao.findAll()).thenReturn(transList);
       	retransList = service.getAll();
       	assertEquals(transList, retransList);
        }
        catch (NoRecordsException e){
        	e.getMessage();
        	
        }
       
	}
	
		

}
