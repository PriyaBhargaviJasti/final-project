package com.fis.customer.model;

import java.util.List;

public class CustomerDTO {

	private List<Customer> list;

	public List<Customer> getList() {
		return list;
	}

	public void setList(List<Customer> list) {
		this.list = list;
	}

	
	
	@Override
	public String toString() {
		return "customerDTO [list=" + list + "]";
	}

	
	
	
}
