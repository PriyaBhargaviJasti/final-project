package com.fis.customer.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fis.customer.Exception.CustomerNotFound;
import com.fis.customer.dao.CustomerDao;
import com.fis.customer.model.Customer;

@Service
public class CustomerService {
	@Autowired
	private CustomerDao dao;
	
	public List<Customer> getCustomers(){
	
		List<Customer> list=dao.findAll();
		if(list.isEmpty()) {
			return null;
			//throw new CustomerNotFound("No Customers found");
		}
		else return list;
	}
	
	
}
